package id.ac.polban.jtk.bagibot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BagibotApplication {

	public static void main(String[] args) {
		SpringApplication.run(BagibotApplication.class, args);
	}

}
