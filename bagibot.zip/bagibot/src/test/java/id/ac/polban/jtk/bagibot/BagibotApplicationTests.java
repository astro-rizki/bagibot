package id.ac.polban.jtk.bagibot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BagibotApplicationTests {

	@Test
	void contextLoads() {
	}

}
