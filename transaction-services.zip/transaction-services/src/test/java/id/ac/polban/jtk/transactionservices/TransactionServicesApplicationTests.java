package id.ac.polban.jtk.transactionservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
