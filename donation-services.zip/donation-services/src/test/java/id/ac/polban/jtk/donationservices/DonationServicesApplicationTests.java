package id.ac.polban.jtk.donationservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonationServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
