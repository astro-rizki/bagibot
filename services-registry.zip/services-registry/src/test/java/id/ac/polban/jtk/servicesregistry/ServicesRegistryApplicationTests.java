package id.ac.polban.jtk.servicesregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicesRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
