package id.ac.polban.jtk.chatservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
